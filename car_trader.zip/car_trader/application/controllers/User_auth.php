<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_auth extends CI_Controller {

	function __construct()

	{

        parent::__construct();

        $this->load->model('User_model');
        $data = array();
        $data['user_data'] = $this->session->user_data;

      
    }

	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('user_auth');
		$this->load->view('layout/footer');
	}

	public function register(){
		$this->load->view('layout/header');
		$this->load->view('registration_page');
		$this->load->view('layout/footer');
	}



	public function login(){
		$this->form_validation->set_rules('username', 'Email or Phone required', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');

         if ($this->form_validation->run() == FALSE) { 
            $msg = array(
                'username' => form_error('username'),
                'password' => form_error('password'),
               
                );
		}
		else{
			$username = $this->input->post('username');

			$password = $this->input->post('password');
			$result = array();
			$result['get_data'] = $this->User_model->get_logininformation($username, $password);
			if(!empty($result['get_data'])){
			$new_data = array(
				'id' => $result['get_data']['id'],
				'name' => $result['get_data']['name'],
				'email' => $result['get_data']['email'],
				'phone_no' => $result['get_data']['phone_no'],
				'user_role' => $result['get_data']['user_role'],
				'profile_pic' => $result['get_data']['profile_pic'],
			);
			$this->session->set_userdata('user_data', $new_data);
			
			redirect('product');
		}
		redirect('User_auth');
	  }
	}

	public function add(){
	/*	$this->security->get_csrf_hash();*/
		$this->form_validation->set_rules('name', 'Name', 'required'); 
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('phone_no', 'Phone no', 'required');

			
         if ($this->form_validation->run() == FALSE) { 
            $msg = array(
                'name' => form_error('name'),
                'email' => form_error('email'),
                'password' => form_error('password'),
                'phone_no' => form_error('phone_no'),
                'profile_pic' => form_error('profile_pic'),
                );
         
	}
     else 
     {
	 		$file = $_FILES['profile_pic'];
            $file_name = $file['name'];
            $file_type = $file['type'];
            $file_size = $file['size'];
            $file_path = $file['tmp_name'];
            $ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $path=base_url().'upload/profile/';
          
            
            if($ext != 'jpg' && $ext != 'JPG' && $ext != 'JPEG' && $ext != 'jpeg' && $ext != 'png' && $ext != 'PNG'){
                
                $this->session->set_flashdata('fail','<div class="alert alert-danger"><strong>Warning!</strong> You must enter a image file</div>');
                redirect('user_auth/register');
            }
            else
            {

               
                $uniquesavename=time().uniqid(rand());
                $final_name ='profile'.$uniquesavename.'.'.$ext;
                move_uploaded_file( $file_path, './upload/profile/'.$final_name );


                $file_data = 'upload/profile/'.$final_name;

             



                  $registered_data = array(
                  'name' => $this->input->post('name'),
                  'email' => $this->input->post('email'),
                  'phone_no' => $this->input->post('phone_no'),
                  'password' => $this->input->post('password'),
                  'profile_pic' => $file_data,
                  'user_role' => $this->input->post('user_role'),
                  'created_at' => date('Y-m-d H:i:s'),
                );


                $insert_id = $this->User_model->insert_user($registered_data);


			}
			redirect('user_auth');
		}
	}

	public function logout()
{
    $user_data = $this->session->all_userdata();
        foreach ($user_data as $key => $value) {
            if ($key != 'session_id' && $key != 'ip_address' && $key != 'user_agent' && $key != 'last_activity') {
                $this->session->unset_userdata($key);
            }
        }
    $this->session->sess_destroy();
    redirect('user_auth');
}

	
}
