<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	function __construct()

	{

        parent::__construct();
        $this->load->library('cart');

        $this->load->model('Product_model');
        $data = array();   
    }

    public function index(){
    	
		        $data['user_data'] = $this->session->user_data;
		        $data['all_product'] = $this->Product_model->allProduct();
		         $data['all_cart_items'] = $this->Product_model->all_cart_details($data['user_data']['id']);
		         $data['count_items'] = count($data['all_cart_items']);
		      /*  print_r($data['all_product']); exit;*/
				$this->load->view('layout/header',$data);
				$this->load->view('product_listing_page',$data);
				$this->load->view('layout/footer');
	
    }
    public function show_one_product($id)
  	{
			$data['user_data'] = $this->session->user_data;
		    $data['one_product'] = $this->Product_model->oneProduct($id);
		    $data['pictures'] = $this->Product_model->show_product_pictures($id);
		    $data['all_cart_items'] = $this->Product_model->all_cart_details($data['user_data']['id']);
		    $data['count_items'] = count($data['all_cart_items']);
			$this->load->view('layout/header',$data);
			$this->load->view('product_listing_one',$data);
			$this->load->view('layout/footer');
	}

	public function search()
	{
		  $output = '<div class="container">
  						<div class="row">';
		  $query = '';
		  //$this->load->model('ajaxsearch_model');
		  if($this->input->post('query'))
		  {
		   $query = $this->input->post('query');
		  }
		  $fetch_data = $this->Product_model->fetch_data($query);
		  if($fetch_data->num_rows() > 0)
  {
   foreach($fetch_data->result_array() as $products)
   {
   	 $output.='
  			<a href="'.base_url().'index.php/product/show_one_product/'.$products['id'].'"><div class="col-md-3">
  				<img src="'.base_url().''.$products['product_pic'].'" class="img-thumbnail" style="height: 320px;">
  				<p>'.$products['product_name'].'</p>
  				<p>Description: '.$products['product_description'].'</p>
  				<p>Price(Rupees):'.$products['product_price'].'</p>

  			</div>
  		</a>';
  	 }
  	}else{
  	$output.='<p>No Data Found</a>';
  }
  $output.='</div></div>';
  echo $output;
   }

	public function add_cart($id){

		$data['user_data'] = $this->session->user_data;
		$buyer_id = $data['user_data']['id'];
		$data['cart_product'] = $this->Product_model->get_cart_product($id);
		$cart_data = array(
			'buyer_id'    => $buyer_id,
            'product_id'    => $id,
            'quantity' => 1,
            'price'    => $data['cart_product']['product_price'],
		);
		$insert_id = $this->Product_model->insert_to_cart($cart_data);

		 $data['all_cart_items'] = $this->Product_model->all_cart_details($data['user_data']['id']);
		 $data['count_items'] = count($data['all_cart_items']);
		 $data['one_product'] = $this->Product_model->oneProduct($id);
		 $data['pictures'] = $this->Product_model->show_product_pictures($id);
	     $this->load->view('layout/header',$data);
	     $this->load->view('product_listing_one',$data);
		 $this->load->view('layout/footer');
		 redirect('Product/index');
	}

	public function make_payment()
	{
		$data['user_data'] = $this->session->user_data;
        
		$data['all_cart_items'] = $this->Product_model->all_cart_details($data['user_data']['id']);
		$order_no = uniqid();
		$update_cart_array= array('order_no' => $order_no, 'order_status' => '1');
		foreach ($data['all_cart_items'] as $value) {
			$this->db->where('product_id', $value['product_id']);
			$this->db->where('order_status', '0');
           $this->db->update('cart_items', $update_cart_array);
		}
		$order_array = array(
           'order_no' => $order_no,
           'order_address' => $this->input->post('order_address'),
           'payment_amount' => $this->input->post('payable_amount'),
           'payment_status' => '1'
		);
		$insert_id = $this->Product_model->insert_order($order_array);
		redirect('product');
	}

	public function show_cartItems($user_id){
		$data['user_data'] = $this->session->user_data;
        
		/*$data['all_cart_data'] = $this->Product_model->all_cart_details($user_id);*/
		$data['all_cart_sum'] = $this->Product_model->sum_price_data($user_id);
		/*print_r($data['all_cart_data']); exit;*/
		 $data['all_cart_items'] = $this->Product_model->all_cart_details($data['user_data']['id']);
		 $data['count_items'] = count($data['all_cart_items']);
		  $this->load->view('layout/header',$data);
	     $this->load->view('product_cart_items',$data);
		 $this->load->view('layout/footer');


	}

	public function add_product(){
		$this->form_validation->set_rules('product_name', 'Product Name', 'required'); 
		/*$this->form_validation->set_rules('product_price', 'Product Price', 'required|numeric|greater_than[0.99]|regex_match[/^[0-9,]+$/]');
		$this->form_validation->set_rules('product_image', 'Product Image', 'required');*/

		  if ($this->form_validation->run() == FALSE) { 
            $msg = array(
                'product_name' => form_error('product_name'),
                'product_price' => form_error('product_price'),
                'product_image' => form_error('product_image'),
                );
           $this->session->set_flashdata('fail','<div class="alert alert-danger"><strong>Warning!</strong>$msg</div>');
		}
		else
		{
			$product_data = array(
				'product_name' => $this->input->post('product_name'),
				'product_price' => $this->input->post('product_price'),
				'product_description' => $this->input->post('product_description'),
				'seller_id' => $this->input->post('seller_id'),
				'created_at' => date('Y-m-d H:i:s'),
			);
			$insert_id = $this->Product_model->add_product($product_data);
			///////////multiple fileupload////////////////////////
			
		    $cpt = count($_FILES['product_image']['name']);
		    for($i=0; $i<$cpt; $i++){
		    $file = $_FILES['product_image'];	
            $file_name = $file['name'][$i];
            $file_type = $file['type'][$i];
            $file_size = $file['size'][$i];
            $file_path = $file['tmp_name'][$i];
            $ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $path=base_url().'upload/product/';
          
            
            if($ext != 'jpg' && $ext != 'JPG' && $ext != 'JPEG' && $ext != 'jpeg' && $ext != 'png' && $ext != 'PNG'){
                
                $this->session->set_flashdata('fail','<div class="alert alert-danger"><strong>Warning!</strong> You must enter a image file</div>');
                redirect('user_auth/login');
            }
            else
            {

               
                $uniquesavename=time().uniqid(rand());
                $final_name ='product'.$uniquesavename.'.'.$ext;
                move_uploaded_file( $file_path, './upload/product/'.$final_name );


                $file_data = 'upload/product/'.$final_name;

             $picture_data = array(
                  
                  'product_pic' => $file_data,
                  'product_id' => $insert_id,
                  'created_at' => date('Y-m-d H:i:s'),
                );


                $this->Product_model->add_product_picture($picture_data);
				
			}
		    }

		     redirect('product');

		}
		
	}
}