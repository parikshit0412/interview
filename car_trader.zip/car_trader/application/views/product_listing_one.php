 <div class="container">
  	<div class="row">
  		<?php foreach($pictures as $all_pictures){?>
  			<div class="col-md-3">
  				<img src="<?=base_url();?><?=$all_pictures['product_pic'];?>" class="img-thumbnail" style="height: 320px;">

  			</div>
  		
  		<?php }?>
  	</div>
    <div class="row">
      <p><?=$one_product['product_name'];?></p><br/>
      <p><h6>Description</h6>
        <?=$one_product['product_description'];?></p><br/>
      <p><h6>Price</h6>  
         <?=$one_product['product_price'];?></p><br/>
         <?php if($user_data['user_role'] == 'buyer'){?>
          <a href="<?=base_url()?>index.php/product/add_cart/<?=$one_product['id'];?>" class="btn btn-primary">Add to Cart</a>
        <?php }?> 
    </div>
  </div>