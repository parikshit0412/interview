
<div class="form-group">
	<?php if($user_data['user_role'] == 'seller'){?>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add Product</button>
	<?php }?><br/><br/>
    <div class="input-group">
     <span class="input-group-addon">Search</span>
     <input type="text" name="search_text" id="search_text" placeholder="Search by Product Details" class="form-control" />
    </div>
   </div>
   <br />
   <div id="result"></div>
  </div>
  <div style="clear:both"></div>

	<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
       <?php echo form_open_multipart(base_url().'index.php/product/add_product',array('class' => 'form-horizontal')); ?>
          <div class="container">
          	<div class="row">
       
    <label for="uname"><b>Product Name</b></label>
    <input type="text" placeholder="Enter Product Name" name="product_name" required>
</div>
<div class="row">
    <label for="product_description"><b>Product Description</b></label>
    <textarea name="product_description"></textarea>
</div>

<div class="row">
    <label for="product_price"><b>Product Price(Rupees)</b></label>
    <input type="text" placeholder="Enter Product Price" name="product_price" required>
</div>
<input type="hidden" name="seller_id" value="<?=$user_data['id']?>">
<div class="row">

    <label for="product_image"><b>Product Image</b></label>
    <input type="file" name = "product_image[]" multiple="multiple" required> <br/><br/>
</div>
    <div class="row">

    <button type="submit" class="btn btn-primary">Add Product</button><br/><br/>
</div>
   
  </div>
  
  <?php echo form_close();?>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <div class="container" id="show_all">
  	<div class="row">
  		<?php foreach($all_product as $products){?>
  			<a href="<?=base_url();?>index.php/product/show_one_product/<?=$products['id']?>"><div class="col-md-3">
  				<img src="<?=base_url();?><?=$products['product_pic'];?>" class="img-thumbnail" style="height: 320px;">
  				<p><?=$products['product_name'];?></p>
  				<p>Description: <?=$products['product_description'];?></p>
  				<p>Price(Rupees):<?=$products['product_price'];?></p>

  			</div>
  		</a>
  		<?php }?>
  	</div>
  </div>
  <script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"<?php echo base_url(); ?>index.php/product/search",
   method:"POST",
   data:{query:query},
   success:function(data){
   	$('#show_all').hide();
    $('#result').html(data);
   }
  })
 }

 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>
