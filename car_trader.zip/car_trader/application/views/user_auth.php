
<?php echo validation_errors('<div class = "alert alert-danger">','</div>');?>
<h2>Login Form</h2>

<?php echo form_open(base_url().'index.php/user_auth/login',array('class' => 'form-horizontal')); ?>

  <div class="container">
    <label for="uname"><b>Email or Phone Number</b></label>
    <input type="text" placeholder="Enter Email or Phone Number" name="username" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
    

    <button type="submit">Login</button><br/><br/>
    <a class="btn btn-primary" href="<?=base_url()?>index.php/user_auth/register">Register Here</a>
   
  </div>
<?php echo form_close();?>


