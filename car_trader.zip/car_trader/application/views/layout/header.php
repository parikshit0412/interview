<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?=base_url()?>index.php/product">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="<?=base_url()?>index.php/product">Home</a></li>
      <?php if(isset($user_data)){?>
       <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $user_data['name'];?>
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="<?=base_url()?>index.php/user_auth/logout">Log Out</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li>
    <?php }?>
      <li><a href="#">Page 2</a></li>
      <?php if(isset($user_data)){?>
      <li><a href="<?=base_url();?>index.php/product/show_cartItems/<?=$user_data['id'];?>"><i class="fa fa-shopping-cart" style="font-size:30px;color:red"></i><?php if(isset($count_items)){?><sapn style="font-size:20px;color:red"><?=$count_items?></sapn><?php }?></a></li><?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="<?=base_url()?>index.php/user_auth/register"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="<?=base_url()?>index.php/user_auth/index"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>