<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class User_model extends CI_Model 

{
  public function insert_user($data){
    $this->db->insert('user_table', $data);
    return $this->db->insert_id();

  }

  public function get_logininformation($username, $password)
  {
        $this->db->select('user_table.*, user_type.user_role');
        $this->db->from('user_table');
        $this->db->where('user_table.email', $username);
        $this->db->or_where('user_table.phone_no', $username);
        $this->db->where('user_table.password', $password);
        $this->db->join('user_type', 'user_table.user_role = user_type.id', 'left');
        $query = $this->db->get();
        return $query->row_array();
  }

  public function add_product($data){
    $this->db->insert('product_table', $data);
    return $this->db->insert_id();
  }

  public function add_product_picture($data){
     $this->db->insert('product_picture', $data);
    return $this->db->insert_id();
  }
    

    }