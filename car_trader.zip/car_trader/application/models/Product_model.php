<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Product_model extends CI_Model 

{
  

  public function add_product($data){
    $this->db->insert('product_table', $data);
    return $this->db->insert_id();
  }

  public function add_product_picture($data){
     $this->db->insert('product_picture', $data);
    return $this->db->insert_id();
  }

  public function allProduct(){
     $this->db->select('product_table.*, product_picture.product_pic,product_picture.product_id');
        $this->db->from('product_table');
        $this->db->where('product_table.available', '1');
        $this->db->join('product_picture', 'product_picture.product_id = product_table.id', 'left');
        $this->db->group_by('product_table.product_name');
        $this->db->order_by('product_table.id','desc');
        $query = $this->db->get();
        return $query->result_array();
  }

  public function oneProduct($id){
    $this->db->select('*');
        $this->db->from('product_table');
        $this->db->where('product_table.id', $id);
        $this->db->where('product_table.available', '1');
        $query = $this->db->get();
        return $query->row_array();
  }

  public function get_cart_product($id){
     $this->db->select('product_table.*, product_picture.product_pic,product_picture.product_id');
        $this->db->from('product_table');
        $this->db->where('product_table.id', $id);
        $this->db->where('product_table.available', '1');
        $this->db->join('product_picture', 'product_picture.product_id = product_table.id', 'left');
        $this->db->group_by('product_table.product_name');
        $query = $this->db->get();
        return $query->row_array();
  }

  public function fetch_data($query){
    $this->db->select("product_table.*, product_picture.product_pic,product_picture.product_id");
  $this->db->from("product_table");
  $this->db->where('product_table.available', '1');
   $this->db->join('product_picture', 'product_picture.product_id = product_table.id', 'left');
   $this->db->group_by('product_table.product_name');
  if($query != '')
  {
   $this->db->like('product_name', $query);
   $this->db->or_like('product_price', $query);
   $this->db->or_like('product_description', $query);
   
  }
  $this->db->order_by('id', 'DESC');
  return $this->db->get();
 }


  public function show_product_pictures($id){
    $this->db->select('*');
        $this->db->from('product_picture');
        $this->db->where('product_picture.product_id', $id);
        $query = $this->db->get();
        return $query->result_array();
  }

  public function insert_to_cart($data)
  {
    $this->db->insert('cart_items', $data);
    return $this->db->insert_id();
  }

  public function all_cart_details($user_id){
        $this->db->select('cart_items.*,product_table.id as pid,product_table.product_name,product_table.product_description');
        $this->db->from('cart_items');
        $this->db->where('cart_items.buyer_id', $user_id);
        $this->db->where('cart_items.order_status', '0');
         $this->db->join('product_table', 'product_table.id = cart_items.product_id', 'left');
        $query = $this->db->get();
        return $query->result_array();
  }

  public function sum_price_data($user_id){
     $this->db->select('sum(price) as total_price');
        $this->db->from('cart_items');
        $this->db->where('cart_items.buyer_id', $user_id);
        $this->db->where('cart_items.order_status', '0');
        $query = $this->db->get();
        return $query->row_array();
  }
  public function insert_order($data){
    $this->db->insert('order_details', $data);
    return $this->db->insert_id();
  }
    

    }